"""Figures for the revised manuscript. Usage: python figures.py results"""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from optimizers import BENCHMARKS, run, init_point, memberships, fuzzy_lr

R = sys.argv[1] if len(sys.argv) > 1 else "results"
C = {"GD+M": "#2a78d6", "FLO": "#eb6834", "HFM": "#1baf7a"}
LS = {"GD+M": "-", "FLO": "--", "HFM": "-."}
MK = {"GD+M": "o", "FLO": "s", "HFM": "^"}
plt.rcParams.update({"font.family": "serif", "font.size": 7, "axes.titlesize": 7, "axes.labelsize": 7,
                     "legend.fontsize": 6.5, "xtick.labelsize": 6, "ytick.labelsize": 6, "lines.linewidth": 1.4,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": "#e4e4e0", "grid.linewidth": 0.5, "savefig.dpi": 300})
INK = "#333333"

# ---------------- Fig. A: fuzzy decision trace ----------------
fig, ax4 = plt.subplots(1, 4, figsize=(7.16, 1.95)); ax = np.array([[ax4[0], ax4[1]], [ax4[2], ax4[3]]])
g = np.linspace(0, 700, 1401)
mus = np.array([memberships(x) for x in g])
a = ax[0, 0]
for k, (lab, ls) in enumerate(zip(["Small $\\mu_S$", "Medium $\\mu_M$", "Large $\\mu_L$"], ["-", "--", ":"])):
    a.plot(g, mus[:, k], ls, color=INK, label=lab)
a.axvline(100, color="#999999", lw=0.8)
a.plot([100, 100], [2 / 3, 1 / 3], "o", color=INK, ms=4)
for tx, ty, tt in [(60, 1.03, "S"), (215, 1.03, "M"), (600, 1.03, "L")]: a.text(tx, ty, tt, fontsize=6.5, ha="left", va="bottom")
a.text(108, 0.12, "$g{=}100$", fontsize=5.5, color="#666666")
a.set(xlabel="gradient norm $g$", ylabel="membership degree", title="(a) Memberships, (4)–(6)", ylim=(-0.03, 1.15))
a = ax[0, 1]
al = [fuzzy_lr(x) for x in g[1:]]
a.plot(g[1:], al, color=INK)
a.plot(100, 0.004, "o", color=INK, ms=4)
a.annotate("$\\alpha(100)=0.004$", (100, 0.004), (170, 0.0042), fontsize=6)
a.set(xlabel="gradient norm $g$", ylabel="learning rate $\\alpha$", title="(b) Output α(g), (7)")
# HFM trace on Rosenbrock 2D seed 0
f, gr, w = BENCHMARKS["Rosenbrock"]
res = run("HFM", f, gr, init_point(0, 2, w), max_iter=500, trace=True)
tr = pd.DataFrame(res["trace"])
a = ax[1, 0]
a.semilogy(tr.it, tr.g, color=INK, lw=1)
a.axhline(50, color="#999999", lw=0.7, ls="--"); a.axhline(200, color="#999999", lw=0.7, ls="--")
a.text(500, 55, "50", fontsize=6, ha="right", color="#666666"); a.text(500, 220, "200", fontsize=6, ha="right", color="#666666")
a.set(xlabel="iteration $t$", ylabel="$g_t$", title="(c) HFM run: $g_t$")
a = ax[1, 1]
a.plot(tr.it, tr.alpha * 1000, color=INK, lw=1, label="$\\alpha_t$ (×10$^{-3}$)")
a.plot(tr.it, tr.beta * 5, color="#888888", lw=0.8, label="$\\beta_t$ (×5)")
att = tr[tr.s < 1]
a.plot(att.it, np.full(len(att), 0.25), "|", color="#555555", ms=4, mew=0.4, label=f"$s_t=0.5$ ({len(att)} of {len(tr)} its)")
a.set(xlabel="iteration $t$", ylabel="value (scaled)", title="(d) HFM run: $\\alpha_t$, $\\beta_t$, $s_t$")
a.legend(loc="center", bbox_to_anchor=(0.70, 0.47), frameon=False, fontsize=5.5, handlelength=1.5)
fig.tight_layout(); fig.savefig(f"{R}/fig_fuzzy_trace.png"); plt.close(fig)

# ---------------- Fig. B: median convergence ----------------
fig, axs = plt.subplots(1, 4, figsize=(7.16, 2.05)); fails = 0
for a, (b, d) in zip(axs, [("Rosenbrock", 2), ("Sphere", 2), ("Beale", 2), ("Rosenbrock", 10)]):
    f, gr, w = BENCHMARKS[b]
    for m in ["GD+M", "FLO", "HFM"]:
        H, nf = [], 0
        for s in (range(30) if d == 2 else range(1000, 1030)):
            x0 = init_point(s, d, w)
            r = run(m, f, gr, x0, max_iter=500, trace=True)
            if r["failed"]: nf += 1; continue
            h = [f(x0)] + [t["f"] for t in r["trace"]]
            h = h + [h[-1]] * (501 - len(h)); H.append(h)
        med = np.median(np.maximum(np.array(H), 1e-20), axis=0)
        a.semilogy(med, LS[m], color=C[m], label=m)
        if nf: fails = nf
    a.set(title=f"{b} {d}D" + (f"\n(GD+M: {fails}/30 failed)" if b == "Rosenbrock" else ""), xlabel="iteration")
    fails = 0
axs[0].set_ylabel("median $f(x_t)$")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.0))
fig.tight_layout(rect=(0, 0, 1, 0.87), w_pad=0.4); fig.savefig(f"{R}/fig_convergence.png"); plt.close(fig)

# ---------------- Fig. C: scaling ----------------
e5 = pd.read_csv(f"{R}/E5_scaling.csv"); e5 = e5[e5.benchmark == "Rosenbrock"]
fig, ax = plt.subplots(1, 2, figsize=(3.5, 1.75))
for m in ["GD+M", "FLO", "HFM"]:
    ds, rel, fl = [], [], []
    for d in sorted(e5.dim.unique()):
        x = e5[(e5.dim == d) & (e5.method == m)]; ok = x[~x.failed]
        fl.append(x.failed.sum())
        if len(ok): ds.append(d); rel.append((ok.f_final / ok.f0).median())
    ax[0].loglog(ds, rel, LS[m], marker=MK[m], color=C[m], ms=3, label=m)
    ax[1].plot(sorted(e5.dim.unique()), fl, LS[m], marker=MK[m], color=C[m], ms=3, label=m)
ax[0].set(xlabel="dimension $d$", ylabel="ratio", title="(a) Median $f_{500}/f_0$ (successful)")
ax[1].set(xscale="log", xlabel="dimension $d$", ylabel="count", title="(b) Failures (of 30)", ylim=(-1, 31))
for a in ax:
    a.set_xticks([2, 5, 10, 20, 50, 100]); a.set_xticklabels(["2", "5", "10", "20", "50", "100"])
ax[1].legend(frameon=False, fontsize=5.5, loc="center right")
fig.tight_layout(pad=0.3, w_pad=0.6); fig.savefig(f"{R}/fig_scaling.png"); plt.close(fig)
print("figures done")
