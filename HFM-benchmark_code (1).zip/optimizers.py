"""
Reference implementation of GD+M, FLO and HFM for the ICoDMI 2026 paper
"Comparative Analysis of Gradient-Based, Fuzzy, and Hybrid Fuzzy-Momentum
Optimization Methods on Non-Convex Benchmark Functions".

Written from the specification in the manuscript (Eqs. (1)-(6), Table III).
HFM follows the original study code: Eqs. (9)-(13) of the revised paper.

Cost accounting: every call to grad() and to f() made BY THE ALGORITHM is
counted. Objective values recorded only for logging are not counted.
"""
import numpy as np

# ----------------------------------------------------------------------------
# Benchmark functions (analytic gradients). All have global minimum f* = 0.
# ----------------------------------------------------------------------------

def rosenbrock(x):
    return float(np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1.0 - x[:-1]) ** 2))

def rosenbrock_grad(x):
    g = np.zeros_like(x)
    d = x[1:] - x[:-1] ** 2
    g[:-1] += -400.0 * x[:-1] * d - 2.0 * (1.0 - x[:-1])
    g[1:] += 200.0 * d
    return g

def sphere(x):
    return float(np.sum(x ** 2))

def sphere_grad(x):
    return 2.0 * x

def himmelblau(x):
    a, b = x
    return float((a * a + b - 11) ** 2 + (a + b * b - 7) ** 2)

def himmelblau_grad(x):
    a, b = x
    u, v = a * a + b - 11, a + b * b - 7
    return np.array([4 * a * u + 2 * v, 2 * u + 4 * b * v])

def ackley(x):
    d = len(x)
    r = np.sqrt(np.sum(x ** 2) / d)
    return float(-20 * np.exp(-0.2 * r) - np.exp(np.sum(np.cos(2 * np.pi * x)) / d) + 20 + np.e)

def ackley_grad(x):
    d = len(x)
    r = np.sqrt(np.sum(x ** 2) / d)
    g1 = np.zeros_like(x) if r < 1e-300 else 4.0 * np.exp(-0.2 * r) * x / (d * r)
    g2 = np.exp(np.sum(np.cos(2 * np.pi * x)) / d) * 2 * np.pi * np.sin(2 * np.pi * x) / d
    return g1 + g2

def rastrigin(x):
    return float(10 * len(x) + np.sum(x ** 2 - 10 * np.cos(2 * np.pi * x)))

def rastrigin_grad(x):
    return 2 * x + 20 * np.pi * np.sin(2 * np.pi * x)

def beale(x):
    a, b = x
    return float((1.5 - a + a * b) ** 2 + (2.25 - a + a * b ** 2) ** 2 + (2.625 - a + a * b ** 3) ** 2)

def beale_grad(x):
    a, b = x
    t1, t2, t3 = 1.5 - a + a * b, 2.25 - a + a * b ** 2, 2.625 - a + a * b ** 3
    ga = 2 * t1 * (b - 1) + 2 * t2 * (b ** 2 - 1) + 2 * t3 * (b ** 3 - 1)
    gb = 2 * t1 * a + 2 * t2 * 2 * a * b + 2 * t3 * 3 * a * b ** 2
    return np.array([ga, gb])

# name -> (f, grad, init half-width)  [Table II]
BENCHMARKS = {
    "Rosenbrock": (rosenbrock, rosenbrock_grad, 2.0),
    "Sphere": (sphere, sphere_grad, 2.0),
    "Himmelblau": (himmelblau, himmelblau_grad, 2.0),
    "Ackley": (ackley, ackley_grad, 5.0),
    "Rastrigin": (rastrigin, rastrigin_grad, 5.0),
    "Beale": (beale, beale_grad, 2.0),
}

# ----------------------------------------------------------------------------
# Fuzzy learning-rate controller, Eqs. (3)-(6)
# ----------------------------------------------------------------------------
T1, T2, T3 = 50.0, 200.0, 500.0           # membership breakpoints
SINGLETONS = (0.005, 0.002, 0.0005)       # consequents for S, M, L
ALPHA_FALLBACK = SINGLETONS[0]   # alpha(0) := right-hand limit; never reached since runs stop at ||grad|| < 1e-8

def memberships(g, scale=1.0):
    t1, t2, t3 = T1 * scale, T2 * scale, T3 * scale
    mu_s = max(0.0, min(g / t1, (t2 - g) / (t2 - t1)))
    mu_m = max(0.0, min((g - t1) / (t2 - t1), (t3 - g) / (t3 - t2)))
    mu_l = max(0.0, min((g - t2) / (t3 - t2), 1.0))
    return mu_s, mu_m, mu_l

def fuzzy_lr(g, scale=1.0, lr_scale=1.0):
    mus = memberships(g, scale)
    den = sum(mus)
    if den <= 1e-12:
        return ALPHA_FALLBACK * lr_scale
    return lr_scale * sum(m * s for m, s in zip(mus, SINGLETONS)) / den

# ----------------------------------------------------------------------------
# Optimizers
# ----------------------------------------------------------------------------
FAIL_BOUND = 1e10   # |f| or |x| above this, or non-finite -> numerical failure


def _failed(x, fx):
    return (not np.all(np.isfinite(x))) or (not np.isfinite(fx)) or abs(fx) > FAIL_BOUND \
        or np.max(np.abs(x)) > 1e6


def run(method, f, grad, x0, max_iter=500, tol=1e-8, f_target=None,
        alpha=0.001, beta=0.9,                   # GD+M
        thr_scale=1.0, lr_scale=1.0,             # FLO / HFM fuzzy controller
        beta_min=0.3, beta_max=0.9, gamma=0.95, s_att=0.5,   # HFM
        noise_sigma=0.0, rng=None, trace=False):
    """Run one optimization. Returns dict with final f, failure flag, counts.

    Stopping: ||grad|| < tol, max_iter reached, or numerical failure.
    If f_target is given, also records the first iteration / cost at which
    f(x_t) - f* <= f_target (monitoring only, not counted as cost).
    """
    x = np.array(x0, dtype=float)
    v = np.zeros_like(x)
    n_grad = n_f = 0
    g_prev = None
    hit_iter = hit_cost = None
    f0 = f(x)
    ema = None
    if method == "HFM":
        ema = f0; n_f += 1          # EMA initialized with f(x0): one counted call
    tr = [] if trace else None
    failed = False
    it = 0
    if f_target is not None and f0 <= f_target:
        hit_iter, hit_cost = 0, n_grad + n_f
    for it in range(1, max_iter + 1):
        gr = grad(x); n_grad += 1
        if noise_sigma > 0:
            gr = gr + rng.normal(0.0, noise_sigma, size=gr.shape)
        gn = float(np.linalg.norm(gr))
        if not np.isfinite(gn):
            failed = True; break
        if gn < tol:
            break
        if method == "GD+M":
            v = beta * v - alpha * gr
            x = x + v
        elif method == "FLO":
            a = fuzzy_lr(gn, thr_scale, lr_scale)
            x = x - a * gr
        elif method == "HFM":
            a = fuzzy_lr(gn, thr_scale, lr_scale)
            # Eq. (9): cosine similarity between successive gradients (c_0 = 1)
            if g_prev is None or np.linalg.norm(g_prev) <= 1e-12:
                c = 1.0
            else:
                c = float(np.clip(np.dot(g_prev, gr) / (np.linalg.norm(g_prev) * gn), -1.0, 1.0))
            # Eq. (10): adaptive momentum, beta_t = max(beta_min, beta_max (1 + c_t) / 2)
            b = max(beta_min, beta_max * (0.5 + 0.5 * c))
            # Eq. (11): EMA of the objective, updated with f(x_t)
            if it == 1:
                f_cur = f0                      # f(x_0) already evaluated (and counted) for m_0
            else:
                f_cur = f(x); n_f += 1
            if not np.isfinite(f_cur):
                failed = True; break
            ema = gamma * ema + round(1.0 - gamma, 12) * f_cur   # same arithmetic as the original code (0.95, 0.05)
            # Eq. (12): attenuation of the gradient term when f(x_t) is above its trend
            s = 1.0 if f_cur <= ema else s_att
            # Eq. (13): momentum update
            v = b * v - s * a * gr
            x = x + v
            g_prev = gr
            if trace:
                tr.append(dict(it=it, g=gn, mu=memberships(gn, thr_scale), alpha=a,
                               cos=c, beta=b, s=s, f=f(x), ema=ema))
        else:
            raise ValueError(method)
        if method != "HFM" and trace:
            tr.append(dict(it=it, g=gn, mu=memberships(gn, thr_scale),
                           alpha=(fuzzy_lr(gn, thr_scale, lr_scale) if method == "FLO" else alpha),
                           f=f(x)))
        fx = f(x)  # monitoring only
        if _failed(x, fx):
            failed = True; break
        if f_target is not None and hit_iter is None and fx <= f_target:
            hit_iter, hit_cost = it, n_grad + n_f
    fx = f(x)
    if not failed and _failed(x, fx):
        failed = True
    return dict(f=(np.nan if failed else fx), failed=failed, iters=it,
                n_grad=n_grad, n_f=n_f, hit_iter=hit_iter, hit_cost=hit_cost,
                x=x, trace=tr)


def init_point(seed, d, half_width):
    # same generator and seeds as the original study (numpy RandomState)
    return np.random.RandomState(seed).uniform(-half_width, half_width, d)
