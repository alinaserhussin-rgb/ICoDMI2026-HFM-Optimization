import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({"font.family": "serif", "font.size": 6.5, "mathtext.fontset": "dejavuserif", "savefig.dpi": 300})
fig, ax = plt.subplots(figsize=(7.16, 1.7)); ax.set_xlim(0, 200); ax.set_ylim(0, 47.5); ax.axis("off")
INK = "#333333"
def box(x, y, w, h, t, fill="#ffffff"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fill, ec=INK, lw=0.6))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", linespacing=1.25)
def arr(p, q, cs=None):
    ax.annotate("", q, p, arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.6, mutation_scale=6, shrinkA=0, shrinkB=0,
                **({"connectionstyle": cs} if cs else {})))
ax.add_patch(FancyBboxPatch((0.5, 26), 199, 21, boxstyle="round,pad=0,rounding_size=1.5", fc="#f1f1ee", ec="none"))
ax.text(2.5, 44.2, "FLO (fuzzy step size)", fontweight="bold", va="center")
ax.text(24, 22.5, "HFM adds adaptive momentum and EMA attenuation", fontweight="bold", va="center")
y1, h1 = 28.5, 12
box(4, y1, 28, h1, "Gradient\n$\\nabla f(x_t)$")
box(40, y1, 30, h1, "Norm\n$g_t=\\|\\nabla f(x_t)\\|_2$  (3)")
box(78, y1, 34, h1, "Fuzzification\n$\\mu_S,\\ \\mu_M,\\ \\mu_L$  (4)–(6)")
box(120, y1, 36, h1, "Singleton inference\n$\\alpha_t\\in[0.0005,\\,0.005]$  (7)")
box(164, y1, 33, h1, "FLO update (8)\n$x_{t+1}=x_t-\\alpha_t\\nabla f(x_t)$")
for a, b in [(32.6, 39.4), (70.6, 77.4), (112.6, 119.4), (156.6, 163.4)]: arr((a, y1 + h1 / 2), (b, y1 + h1 / 2))
y2, h2 = 3, 15
box(4, y2, 34, h2, "Cosine similarity (9)\n$c_t=\\cos(\\nabla f_t,\\nabla f_{t-1})$")
box(46, y2, 33, h2, "Momentum (10)\n$\\beta_t=\\max\\{\\beta_{\\min},\\,\\beta_{\\max}\\frac{1+c_t}{2}\\}$")
box(87, y2, 32, h2, "EMA of objective (11)\n$m_t=\\gamma m_{t-1}+(1-\\gamma)f(x_t)$")
box(127, y2, 30, h2, "Attenuation (12)\n$f(x_t)>m_t\\Rightarrow s_t=0.5$")
box(165, y2, 32, h2, "HFM update (13)\n$v_{t+1}=\\beta_t v_t-s_t\\alpha_t\\nabla f(x_t)$\n$x_{t+1}=x_t+v_{t+1}$")
for a, b in [(38.6, 45.4), (79.6, 86.4), (119.6, 126.4), (157.6, 164.4)]: arr((a, y2 + h2 / 2), (b, y2 + h2 / 2))
arr((18, y1 - 0.6), (18, y2 + h2 + 0.6))
ax.plot([138, 138, 181], [y1 - 0.6, 24.5, 24.5], color=INK, lw=0.6)
arr((181, 24.5), (181, y2 + h2 + 0.6))
ax.text(183, 21.5, "$\\alpha_t$", va="center")
fig.subplots_adjust(0, 0, 1, 1); fig.savefig("results/fig_arch.png"); print("ok")
