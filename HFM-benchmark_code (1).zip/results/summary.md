## Table IV — 500 iterations, 30 starts: median [IQR] of final f over successful runs; failures/30; mean
| Benchmark | GD+M | FLO | HFM |
|---|---|---|---|
| Rosenbrock 2D | 0.00202 [0.00177, 0.00355] f=9 mean=0.00266 | 0.807 [0.606, 1.11] f=0 mean=0.853 | 0.164 [0.0969, 0.617] f=0 mean=0.372 |
| Sphere 2D | 1.41e-11 [5.97e-12, 1.82e-11] f=0 mean=1.31e-11 | 1.23e-04 [5.21e-05, 1.59e-04] f=0 mean=1.14e-04 | 1.07e-17 [7.23e-18, 1.75e-17] f=0 mean=1.17e-17 |
| Himmelblau 2D | 4.17e-19 [2.33e-19, 6.39e-19] f=0 mean=4.40e-19 | 1.33e-18 [5.46e-19, 1.72e-18] f=0 mean=1.12e-18 | 3.82e-19 [2.98e-19, 6.16e-19] f=0 mean=5.27e-19 |
| Ackley 2D | 8.91 [6.88, 10.1] f=0 mean=8.23 | 8.91 [6.88, 10.1] f=0 mean=8.23 | 8.91 [6.88, 10.1] f=0 mean=8.23 |
| Rastrigin 2D | 17.4 [8.95, 24.9] f=0 mean=17 | 17.4 [8.95, 24.9] f=0 mean=17 | 17.4 [8.95, 24.9] f=0 mean=17 |
| Beale 2D | 0.00116 [0.00105, 0.963] f=0 mean=0.328 | 0.0142 [0.0126, 1.03] f=0 mean=0.371 | 3.36e-10 [2.09e-10, 0.838] f=0 mean=0.392 |
| Rosenbrock 10D | 0.00669 [0.00441, 3.99] f=22 mean=1.5 | 8.27 [8.04, 10.9] f=0 mean=9.32 | 8.38 [7.22, 10.3] f=0 mean=10.4 |

## Wilcoxon (paired, successful runs of both), Holm over 14 tests; r = matched-pairs rank-biserial (positive => first method has larger f, i.e. worse)
| Benchmark | Comparison | n | p | p_Holm | r |
|---|---|---|---|---|---|
| Rosenbrock 2D | HFM vs FLO | 30 | 5.97e-06 | 3.58e-05 | -0.86 |
| Rosenbrock 2D | HFM vs GD+M | 21 | 9.54e-07 | 6.68e-06 | 1.00 |
| Sphere 2D | HFM vs FLO | 30 | 1.86e-09 | 1.68e-08 | -1.00 |
| Sphere 2D | HFM vs GD+M | 30 | 1.86e-09 | 1.68e-08 | -1.00 |
| Himmelblau 2D | HFM vs FLO | 30 | – | – | 0.00 |
| Himmelblau 2D | HFM vs GD+M | 30 | – | – | 0.00 |
| Ackley 2D | HFM vs FLO | 30 | – | – | 0.00 |
| Ackley 2D | HFM vs GD+M | 30 | – | – | 0.00 |
| Rastrigin 2D | HFM vs FLO | 30 | 0.00335 | 0.0134 | -1.00 |
| Rastrigin 2D | HFM vs GD+M | 30 | – | – | 0.00 |
| Beale 2D | HFM vs FLO | 30 | 0.00202 | 0.0101 | -0.63 |
| Beale 2D | HFM vs GD+M | 30 | 0.00993 | 0.0234 | -0.53 |
| Rosenbrock 10D | HFM vs FLO | 30 | 0.871 | 0.871 | -0.04 |
| Rosenbrock 10D | HFM vs GD+M | 8 | 0.00781 | 0.0234 | 1.00 |

## Convergence to f - f* <= 1e-6 (max 5000 iterations): success/30; median iterations; median counted calls (gradient + objective)
| Benchmark | GD+M | FLO | HFM |
|---|---|---|---|
| Rosenbrock 2D | 21/30; it=1.4e+03; calls=1.4e+03 | 0/30; it=–; calls=– | 0/30; it=–; calls=– |
| Sphere 2D | 30/30; it=292; calls=292 | 30/30; it=740; calls=740 | 30/30; it=58; calls=116 |
| Himmelblau 2D | 30/30; it=160; calls=160 | 30/30; it=53; calls=53 | 30/30; it=56; calls=112 |
| Ackley 2D | 0/30; it=–; calls=– | 0/30; it=–; calls=– | 0/30; it=–; calls=– |
| Rastrigin 2D | 0/30; it=–; calls=– | 0/30; it=–; calls=– | 0/30; it=–; calls=– |
| Beale 2D | 20/30; it=1.57e+03; calls=1.57e+03 | 20/30; it=3.32e+03; calls=3.32e+03 | 20/30; it=273; calls=546 |
| Rosenbrock 10D | 5/30; it=1.28e+03; calls=1.28e+03 | 0/30; it=–; calls=– | 0/30; it=–; calls=– |

Paired tests on iterations-to-tolerance (seeds where both succeeded):
- Sphere 2D HFM vs FLO: n=30, p=1.86e-09, r=-1.00
- Sphere 2D HFM vs GD+M: n=30, p=1.72e-06, r=-1.00
- Sphere 2D HFM vs FLO (calls): n=30, p=1.86e-09, r=-1.00
- Sphere 2D HFM vs GD+M (calls): n=30, p=1.73e-06, r=-1.00
- Himmelblau 2D HFM vs FLO: n=30, p=0.245, r=0.24
- Himmelblau 2D HFM vs GD+M: n=30, p=1.72e-06, r=-1.00
- Himmelblau 2D HFM vs FLO (calls): n=30, p=1.73e-06, r=1.00
- Himmelblau 2D HFM vs GD+M (calls): n=30, p=1.73e-06, r=-1.00
- Beale 2D HFM vs FLO: n=20, p=1.91e-06, r=-1.00
- Beale 2D HFM vs GD+M: n=20, p=8.79e-05, r=-1.00
- Beale 2D HFM vs FLO (calls): n=20, p=8.81e-05, r=-1.00
- Beale 2D HFM vs GD+M (calls): n=20, p=8.83e-05, r=-1.00

## Himmelblau, n = 100 starts (5000 max iter)
- GD+M: success 100/100, median it 160, median calls 160, median final f 4.88e-19, fails 0
- FLO: success 100/100, median it 47.5, median calls 47.5, median final f 1.01e-18, fails 0
- HFM: success 100/100, median it 55, median calls 110, median final f 4.15e-19, fails 0
- HFM vs FLO on hit_iter: n=100, p=0.227, r=0.14
- HFM vs FLO on hit_cost: n=100, p=4.25e-18, r=1.00
- HFM vs FLO on f_final: n=100, p=–, r=0.00
- HFM vs GD+M on hit_iter: n=100, p=3.86e-18, r=-1.00
- HFM vs GD+M on hit_cost: n=100, p=3.86e-18, r=-1.00
- HFM vs GD+M on f_final: n=100, p=–, r=0.00

## Scaling (500 iterations): median final f [fails/30], median relative reduction f_T/f_0
### Rosenbrock
| d | GD+M | FLO | HFM |
|---|---|---|---|
| 2 | 0.00202 [9] rel=2.65e-05 | 0.807 [0] rel=0.00333 | 0.164 [0] rel=0.00111 |
| 5 | 0.00153 [17] rel=1.90e-06 | 3.39 [0] rel=0.0023 | 4.54 [0] rel=0.00323 |
| 10 | 0.00669 [22] rel=3.99e-06 | 8.27 [0] rel=0.00265 | 8.38 [0] rel=0.00253 |
| 20 | 2.19 [28] rel=6.49e-04 | 18.5 [0] rel=0.00237 | 18.4 [0] rel=0.00238 |
| 50 | – [30] rel=– | 48.2 [0] rel=0.00235 | 48.1 [0] rel=0.0024 |
| 100 | – [30] rel=– | 98 [0] rel=0.0022 | 98.3 [0] rel=0.00229 |
Paired HFM vs FLO by d: d=2: p=5.97e-06, r=-0.86; d=5: p=0.371, r=0.19; d=10: p=0.871, r=-0.04; d=20: p=0.968, r=0.01; d=50: p=0.299, r=0.22; d=100: p=0.191, r=0.28
### Rastrigin
| d | GD+M | FLO | HFM |
|---|---|---|---|
| 2 | 17.4 [0] rel=0.443 | 17.4 [0] rel=0.443 | 17.4 [0] rel=0.443 |
| 5 | 43.3 [0] rel=0.48 | 43.3 [0] rel=0.48 | 43.3 [0] rel=0.48 |
| 10 | 76.6 [0] rel=0.446 | 76.6 [0] rel=0.446 | 76.6 [0] rel=0.446 |
| 20 | 162 [0] rel=0.436 | 162 [0] rel=0.436 | 162 [0] rel=0.436 |
| 50 | 415 [0] rel=0.45 | 415 [0] rel=0.45 | 415 [0] rel=0.45 |
| 100 | 812 [0] rel=0.45 | 812 [0] rel=0.45 | 812 [0] rel=0.45 |
Paired HFM vs FLO by d: d=2: p=0.00335, r=-1.00; d=5: p=0.317, r=-1.00; d=10: p=–, r=0.00; d=20: p=–, r=0.00; d=50: p=–, r=0.00; d=100: p=–, r=0.00

## Gradient noise: median final f [fails/30]
### Rosenbrock 2D
| sigma | GD+M | FLO | HFM |
|---|---|---|---|
| 0.0 | 0.00202 [9] | 0.807 [0] | 0.164 [0] |
| 0.1 | 0.00237 [9] | 0.743 [0] | 0.23 [0] |
| 1.0 | 0.00888 [8] | 0.395 [0] | 0.143 [0] |
| 10.0 | 0.566 [10] | 1 [0] | 0.979 [0] |
### Sphere 2D
| sigma | GD+M | FLO | HFM |
|---|---|---|---|
| 0.0 | 1.41e-11 [0] | 1.23e-04 [0] | 1.07e-17 [0] |
| 0.1 | 4.03e-05 [0] | 1.11e-04 [0] | 4.91e-05 [0] |
| 1.0 | 0.00403 [0] | 0.00229 [0] | 0.00484 [0] |
| 10.0 | 0.403 [0] | 0.231 [0] | 0.488 [0] |
### Ackley 2D
| sigma | GD+M | FLO | HFM |
|---|---|---|---|
| 0.0 | 8.91 [0] | 8.91 [0] | 8.91 [0] |
| 0.1 | 8.91 [0] | 8.91 [0] | 8.81 [0] |
| 1.0 | 8.82 [0] | 8.82 [0] | 8.82 [0] |
| 10.0 | 6.03 [0] | 8.23 [0] | 3.06 [0] |
### Rosenbrock 10D
| sigma | GD+M | FLO | HFM |
|---|---|---|---|
| 0.0 | 0.00669 [22] | 8.27 [0] | 8.38 [0] |
| 0.1 | 0.00727 [22] | 8.55 [0] | 7.59 [0] |
| 1.0 | 0.0646 [22] | 8.56 [0] | 9.23 [0] |
| 10.0 | 4.76 [23] | 10.8 [0] | 11.6 [0] |

## Equal-budget tuned comparison (20 configs each, 10 tuning seeds, evaluated on 30 test seeds): median [fails]; selected config
| Benchmark | GD+M | FLO | HFM |
|---|---|---|---|
| Rosenbrock 2D | 0.065 [0] {"alpha": 0.0003, "beta": 0.9} | 0.0769 [0] {"lr_scale": 0.5, "thr_scale": 4} | 2.07e-06 [0] {"lr_scale": 0.5, "thr_scale": 0.5} |
| Sphere 2D | 1.17e-17 [0] {"alpha": 0.01, "beta": 0.9} | 2.27e-17 [0] {"lr_scale": 10, "thr_scale": 0.5} | 8.15e-18 [0] {"lr_scale": 10, "thr_scale": 0.5} |
| Himmelblau 2D | 3.61e-19 [0] {"alpha": 0.01, "beta": 0.5} | 9.96e-19 [0] {"lr_scale": 2, "thr_scale": 0.5} | 4.47e-19 [0] {"lr_scale": 5, "thr_scale": 4} |
| Ackley 2D | 7.04 [0] {"alpha": 0.01, "beta": 0.99} | 8.91 [0] {"lr_scale": 0.5, "thr_scale": 0.5} | 8.91 [0] {"lr_scale": 1, "thr_scale": 0.5} |
| Rastrigin 2D | 13.6 [0] {"alpha": 0.0003, "beta": 0.99} | 17.4 [0] {"lr_scale": 0.5, "thr_scale": 0.5} | 17.4 [0] {"lr_scale": 0.5, "thr_scale": 0.5} |
| Beale 2D | 4.00e-17 [9] {"alpha": 0.01, "beta": 0.9} | 1.18e-05 [0] {"lr_scale": 5, "thr_scale": 2} | 1.07e-16 [3] {"lr_scale": 10, "thr_scale": 0.5} |
| Rosenbrock 10D | 1.23 [0] {"alpha": 0.0003, "beta": 0.9} | 6.22 [0] {"lr_scale": 0.5, "thr_scale": 0.5} | 1.76 [0] {"lr_scale": 0.5, "thr_scale": 0.5} |
- tuned Rosenbrock 2D HFM vs FLO: n=30, p=1.86e-09, p_Holm=1.68e-08, r=-1.00
- tuned Rosenbrock 2D HFM vs GD+M: n=30, p=1.68e-06, p_Holm=1.01e-05, r=-0.89
- tuned Sphere 2D HFM vs FLO: n=30, p=–, p_Holm=–, r=0.00
- tuned Sphere 2D HFM vs GD+M: n=30, p=–, p_Holm=–, r=0.00
- tuned Himmelblau 2D HFM vs FLO: n=30, p=0.0277, p_Holm=0.0831, r=1.00
- tuned Himmelblau 2D HFM vs GD+M: n=30, p=0.0277, p_Holm=0.0831, r=1.00
- tuned Ackley 2D HFM vs FLO: n=30, p=–, p_Holm=–, r=0.00
- tuned Ackley 2D HFM vs GD+M: n=30, p=0.685, p_Holm=0.685, r=0.09
- tuned Rastrigin 2D HFM vs FLO: n=30, p=–, p_Holm=–, r=0.00
- tuned Rastrigin 2D HFM vs GD+M: n=30, p=0.0137, p_Holm=0.0683, r=-0.51
- tuned Beale 2D HFM vs FLO: n=27, p=1.49e-08, p_Holm=1.19e-07, r=-1.00
- tuned Beale 2D HFM vs GD+M: n=20, p=–, p_Holm=–, r=0.00
- tuned Rosenbrock 10D HFM vs FLO: n=30, p=2.61e-08, p_Holm=1.83e-07, r=-0.97
- tuned Rosenbrock 10D HFM vs GD+M: n=30, p=0.0145, p_Holm=0.0683, r=0.51

## HFM threshold scale (median final f [fails])
| Benchmark | scale=0.5 | scale=0.75 | scale=1.0 | scale=1.25 | scale=1.5 | normalized |
|---|---|---|---|---|---|---|
| Rosenbrock 2D | 0.176 [0] | 0.171 [0] | 0.164 [0] | 0.249 [0] | 0.0969 [0] | 0.228 [8] |
| Sphere 2D | 1.07e-17 [0] | 1.07e-17 [0] | 1.07e-17 [0] | 1.07e-17 [0] | 1.07e-17 [0] | 1.71e-17 [0] |
| Himmelblau 2D | 5.11e-19 [0] | 4.39e-19 [0] | 3.82e-19 [0] | 5.43e-19 [0] | 4.34e-19 [0] | 4.55e-19 [0] |
| Ackley 2D | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] |
| Rastrigin 2D | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] |
| Beale 2D | 3.30e-10 [0] | 3.34e-10 [0] | 3.36e-10 [0] | 3.36e-10 [0] | 3.36e-10 [0] | 3.69e-10 [0] |
| Rosenbrock 10D | 9.27 [0] | 9.09 [0] | 8.38 [0] | 8.48 [0] | 7.79 [0] | 14.8 [29] |

## HFM beta_min (median final f [fails])
| Benchmark | 0 | 0.1 | 0.2 | 0.3 | 0.4 | 0.5 | 0.7 |
|---|---|---|---|---|---|---|---|
| Rosenbrock 2D | 0.382 [0] | 0.326 [0] | 0.337 [0] | 0.164 [0] | 0.15 [0] | 0.107 [0] | 0.0206 [0] |
| Sphere 2D | 1.84e-17 [0] | 2.00e-17 [0] | 5.36e-18 [0] | 1.07e-17 [0] | 1.32e-17 [0] | 2.25e-18 [0] | 3.09e-22 [0] |
| Himmelblau 2D | 4.45e-19 [0] | 5.04e-19 [0] | 4.56e-19 [0] | 3.82e-19 [0] | 4.81e-19 [0] | 5.60e-19 [0] | 4.45e-19 [0] |
| Ackley 2D | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] | 8.91 [0] |
| Rastrigin 2D | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] | 17.4 [0] |
| Beale 2D | 3.39e-10 [0] | 3.39e-10 [0] | 3.39e-10 [0] | 3.36e-10 [0] | 3.21e-10 [0] | 3.35e-10 [0] | 6.62e-10 [0] |
| Rosenbrock 10D | 11.7 [0] | 8.02 [0] | 8.78 [0] | 8.38 [0] | 8.32 [0] | 9.11 [0] | 9.25 [0] |