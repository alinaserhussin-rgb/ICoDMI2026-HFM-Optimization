"""Runs every experiment reported in the revised manuscript and writes CSV logs.
Usage: python experiments.py OUTDIR
"""
import sys, os, itertools, json
import numpy as np, pandas as pd
from optimizers import BENCHMARKS, run, init_point

OUT = sys.argv[1] if len(sys.argv) > 1 else "results"
os.makedirs(OUT, exist_ok=True)
METHODS = ["GD+M", "FLO", "HFM"]
CONFIGS = [("Rosenbrock", 2), ("Sphere", 2), ("Himmelblau", 2), ("Ackley", 2),
           ("Rastrigin", 2), ("Beale", 2), ("Rosenbrock", 10)]


def seeds(d, n=30, offset=0):
    base = 0 if d == 2 else 1000
    return list(range(base + offset, base + offset + n))


def one(bench, d, method, seed, **kw):
    f, g, w = BENCHMARKS[bench]
    r = run(method, f, g, init_point(seed, d, w), **kw)
    return dict(benchmark=bench, dim=d, method=method, seed=seed, f_final=r["f"],
                failed=r["failed"], iters=r["iters"], n_grad=r["n_grad"], n_f=r["n_f"],
                hit_iter=r["hit_iter"], hit_cost=r["hit_cost"])


def save(rows, name):
    df = pd.DataFrame(rows); df.to_csv(f"{OUT}/{name}.csv", index=False); print(name, len(df)); return df


# E1: main comparison (Table IV): 7 configs x 3 methods x 30 seeds, 500 iterations
save([one(b, d, m, s, max_iter=500) for b, d in CONFIGS for m in METHODS for s in seeds(d)], "E1_main")

# E2: iterations / evaluations to reach f - f* <= 1e-6 (budget 5000 iterations)
save([one(b, d, m, s, max_iter=5000, f_target=1e-6) for b, d in CONFIGS for m in METHODS for s in seeds(d)],
     "E2_tolerance")

# E4: Himmelblau with n = 100 paired starts (500 and 5000 iterations)
save([dict(one("Himmelblau", 2, m, s, max_iter=5000, f_target=1e-6)) for m in METHODS for s in range(100)],
     "E4_himmelblau_n100")

# E5: dimensional scaling, Rosenbrock and Rastrigin, d in {2,5,10,20,50,100}
rows = []
for b in ["Rosenbrock", "Rastrigin"]:
    for d in [2, 5, 10, 20, 50, 100]:
        for m in METHODS:
            for s in seeds(d):
                r = one(b, d, m, s, max_iter=500)
                f, _, w = BENCHMARKS[b]; r["f0"] = f(init_point(s, d, w)); rows.append(r)
save(rows, "E5_scaling")

# E6: Gaussian gradient noise
rows = []
for b, d in [("Rosenbrock", 2), ("Sphere", 2), ("Ackley", 2), ("Rosenbrock", 10)]:
    for sig in [0.0, 0.1, 1.0, 10.0]:
        for m in METHODS:
            for s in seeds(d):
                r = one(b, d, m, s, max_iter=500, noise_sigma=sig, rng=np.random.default_rng(s + 10000))
                r["sigma"] = sig; rows.append(r)
save(rows, "E6_noise")

# E7: equal-budget tuning (20 configurations per method) on tuning seeds, evaluation on test seeds
GRIDS = {
    "GD+M": [dict(alpha=a, beta=bb) for a in [1e-4, 3e-4, 1e-3, 3e-3, 1e-2] for bb in [0.0, 0.5, 0.9, 0.99]],
    "FLO": [dict(lr_scale=l, thr_scale=t) for l in [0.5, 1, 2, 5, 10] for t in [0.5, 1, 2, 4]],
    "HFM": [dict(lr_scale=l, thr_scale=t) for l in [0.5, 1, 2, 5, 10] for t in [0.5, 1, 2, 4]],
}
tune_rows, best, test_rows = [], {}, []
for b, d in CONFIGS:
    for m in METHODS:
        scores = []
        for ci, cfg in enumerate(GRIDS[m]):
            res = [one(b, d, m, s, max_iter=500, **cfg) for s in seeds(d, 10, offset=500)]
            vals = [np.inf if r["failed"] else r["f_final"] for r in res]
            nfail = sum(r["failed"] for r in res)
            med = float(np.median(vals))
            scores.append((med, nfail, ci))
            tune_rows.append(dict(benchmark=b, dim=d, method=m, cfg=json.dumps(cfg), median_f=med, fails=nfail))
        med, nfail, ci = min(scores, key=lambda t: (t[0], t[1]))
        best[(b, d, m)] = GRIDS[m][ci]
        for s in seeds(d):
            r = one(b, d, m, s, max_iter=500, **GRIDS[m][ci]); r["cfg"] = json.dumps(GRIDS[m][ci]); test_rows.append(r)
save(tune_rows, "E7_tuning_grid")
save(test_rows, "E7_tuned_test")

# E8: fuzzy-threshold scale sensitivity (HFM), plus gradient-normalized thresholds
rows = []
for b, d in CONFIGS:
    for sc in [0.5, 0.75, 1.0, 1.25, 1.5]:
        for s in seeds(d):
            r = one(b, d, "HFM", s, max_iter=500, thr_scale=sc); r["variant"] = f"scale={sc}"; rows.append(r)
    for s in seeds(d):   # thresholds normalized by the initial gradient norm: T2 <- ||grad f(x0)||
        f, g, w = BENCHMARKS[b]
        g0 = float(np.linalg.norm(g(init_point(s, d, w))))
        r = one(b, d, "HFM", s, max_iter=500, thr_scale=max(g0, 1e-12) / 200.0); r["variant"] = "normalized"; rows.append(r)
save(rows, "E8_thresholds")

# E9: beta_min sensitivity (HFM)
save([dict(one(b, d, "HFM", s, max_iter=500, beta_min=bm), beta_min=bm)
      for b, d in CONFIGS for bm in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7] for s in seeds(d)], "E9_betamin")
print("done")
