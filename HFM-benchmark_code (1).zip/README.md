# HFM-benchmark

Reference implementation and complete experiment logs for
"Comparative Analysis of Gradient-Based, Fuzzy, and Hybrid Fuzzy–Momentum
Optimization Methods on Non-Convex Benchmark Functions" (ICoDMI 2026).

The HFM update is identical to the original study code (Eqs. (9)-(13) of the paper),
and starting points use the same NumPy RandomState seeds.

- `optimizers.py`  GD+M, FLO and HFM (Eqs. (1)-(14)) and the six benchmarks (analytic gradients)
- `experiments.py` runs all 11,640 runs (about 2 minutes), writes `results/*.csv`
- `analyze.py`     tables, Wilcoxon tests with Holm correction -> `results/summary.md`
- `figures.py`, `arch.py`  figures of the paper

    python experiments.py results && python analyze.py results && python figures.py results && python arch.py

Seeds: starts 0-29 (2D), 1000-1029 (d > 2); Himmelblau study 0-99; tuning 500-509 / 1500-1509;
gradient-noise RNG seed = start seed + 10000.  Requirements: numpy, scipy, pandas, matplotlib.
