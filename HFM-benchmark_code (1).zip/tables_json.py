"""Formats every number that appears in the manuscript tables, directly from the CSV logs."""
import json, sys, numpy as np, pandas as pd
sys.argv = [sys.argv[0], "results"]
from analyze import paired_test, holm, summ  # reuses the exact statistics code (also rewrites summary.md)

R = "results"; M = ["GD+M", "FLO", "HFM"]
CONF = [("Rosenbrock", 2), ("Sphere", 2), ("Himmelblau", 2), ("Ackley", 2), ("Rastrigin", 2), ("Beale", 2), ("Rosenbrock", 10)]


def f3(x):
    if x is None or (isinstance(x, float) and not np.isfinite(x)): return "—"
    if x == 0: return "0"
    if 0.01 <= abs(x) < 1000: return f"{x:.3g}"
    m, e = f"{x:.2e}".split("e"); return f"{m}e{int(e)}"


def fp(p):
    if p is None or not np.isfinite(p): return "—"
    return "<1e-6" if p < 1e-6 else (f"{p:.3f}" if p >= 0.001 else f3(p))


out = {}
e1 = pd.read_csv(f"{R}/E1_main.csv")
tests = []
for b, d in CONF:
    for m2 in ["FLO", "GD+M"]:
        tests.append(paired_test(e1, b, d, "HFM", m2))
adj = holm([t[1] for t in tests])
rows = []
for i, (b, d) in enumerate(CONF):
    r = dict(bench=f"{b} {d}D")
    for m in M:
        s = summ(e1[(e1.benchmark == b) & (e1.dim == d) & (e1.method == m)])
        r[m] = dict(med=f3(s["med"]), iqr=f"[{f3(s['q1'])}, {f3(s['q3'])}]", fail=s["fail"])
    nF, _, rF = tests[2 * i]; nG, _, rG = tests[2 * i + 1]
    r["pF"], r["rF"], r["nF"] = fp(adj[2 * i]), f"{rF:+.2f}" if np.isfinite(adj[2 * i]) else "—", nF
    r["pG"], r["rG"], r["nG"] = fp(adj[2 * i + 1]), f"{rG:+.2f}" if np.isfinite(adj[2 * i + 1]) else "—", nG
    rows.append(r)
out["T4"] = rows

e2 = pd.read_csv(f"{R}/E2_tolerance.csv"); rows = []
for b, d in CONF:
    r = dict(bench=f"{b} {d}D")
    for m in M:
        x = e2[(e2.benchmark == b) & (e2.dim == d) & (e2.method == m)]; h = x[x.hit_iter.notna()]
        r[m] = dict(succ=f"{len(h)}/30", it=(f"{h.hit_iter.median():.0f}" if len(h) else "—"),
                    calls=(f"{h.hit_cost.median():.0f}" if len(h) else "—"))
    rows.append(r)
out["T5"] = rows

e4 = pd.read_csv(f"{R}/E4_himmelblau_n100.csv"); hb = {}
for m in M:
    x = e4[e4.method == m]; h = x[x.hit_iter.notna()]
    hb[m] = dict(succ=len(h), it=float(h.hit_iter.median()), calls=float(h.hit_cost.median()))
for m2 in ["FLO", "GD+M"]:
    for col in ["hit_iter", "hit_cost"]:
        n, p, r = paired_test(e4, "Himmelblau", 2, "HFM", m2, col=col); hb[f"{m2}_{col}"] = dict(n=n, p=fp(p), r=f"{r:+.2f}")
out["HB"] = hb

e7 = pd.read_csv(f"{R}/E7_tuned_test.csv"); rows = []; tests = []
for b, d in CONF:
    for m2 in ["FLO", "GD+M"]: tests.append(paired_test(e7, b, d, "HFM", m2))
adj = holm([t[1] for t in tests])
for i, (b, d) in enumerate(CONF):
    r = dict(bench=f"{b} {d}D")
    for m in M:
        x = e7[(e7.benchmark == b) & (e7.dim == d) & (e7.method == m)]; s = summ(x)
        r[m] = dict(med=f3(s["med"]), fail=s["fail"], cfg=json.loads(x.cfg.iloc[0]))
    r["pF"], r["rF"] = fp(adj[2 * i]), (f"{tests[2*i][2]:+.2f}" if np.isfinite(adj[2 * i]) else "—")
    r["pG"], r["rG"] = fp(adj[2 * i + 1]), (f"{tests[2*i+1][2]:+.2f}" if np.isfinite(adj[2 * i + 1]) else "—")
    rows.append(r)
out["T6"] = rows

e6 = pd.read_csv(f"{R}/E6_noise.csv"); rows = []
for b, d in [("Rosenbrock", 2), ("Sphere", 2), ("Ackley", 2), ("Rosenbrock", 10)]:
    for sig in [0.1, 1.0, 10.0]:
        r = dict(bench=f"{b} {d}D", sigma=sig)
        for m in M:
            x = e6[(e6.benchmark == b) & (e6.dim == d) & (e6.method == m) & (e6.sigma == sig)]; s = summ(x)
            r[m] = dict(med=f3(s["med"]), fail=s["fail"])
        rows.append(r)
out["T7"] = rows

e8 = pd.read_csv(f"{R}/E8_thresholds.csv"); e9 = pd.read_csv(f"{R}/E9_betamin.csv"); rows = []
for v, lab in [("scale=0.5", "κ = 0.5"), ("scale=0.75", "κ = 0.75"), ("scale=1.0", "κ = 1 (default)"), ("scale=1.25", "κ = 1.25"),
               ("scale=1.5", "κ = 1.5"), ("normalized", "κ = g₀/200")]:
    r = dict(par=lab)
    for b, d in [("Rosenbrock", 2), ("Rosenbrock", 10), ("Beale", 2)]:
        s = summ(e8[(e8.benchmark == b) & (e8.dim == d) & (e8.variant == v)]); r[f"{b}{d}"] = dict(med=f3(s["med"]), fail=s["fail"])
    rows.append(r)
for bm in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7]:
    r = dict(par=f"β_min = {bm}" + (" (default)" if bm == 0.3 else ""))
    for b, d in [("Rosenbrock", 2), ("Rosenbrock", 10), ("Beale", 2)]:
        s = summ(e9[(e9.benchmark == b) & (e9.dim == d) & (e9.beta_min == bm)]); r[f"{b}{d}"] = dict(med=f3(s["med"]), fail=s["fail"])
    rows.append(r)
out["T8"] = rows

# scaling numbers for text
e5 = pd.read_csv(f"{R}/E5_scaling.csv"); sc = {}
for b in ["Rosenbrock", "Rastrigin"]:
    for d in [2, 5, 10, 20, 50, 100]:
        for m in M:
            x = e5[(e5.benchmark == b) & (e5.dim == d) & (e5.method == m)]
            sc[f"{b}{d}{m}"] = dict(fail=int(x.failed.sum()), med=f3(x[~x.failed].f_final.median()) if (~x.failed).any() else "—")
        n, p, r = paired_test(e5, b, d, "HFM", "FLO"); sc[f"{b}{d}p"] = fp(p)
out["SC"] = sc
# attenuation share in HFM default runs (Rosenbrock 2D)
import optimizers as O
shares = []
for b, d in CONF:
    f, g, w = O.BENCHMARKS[b]; tot = att = 0
    for s in (range(30) if d == 2 else range(1000, 1030)):
        res = O.run("HFM", f, g, O.init_point(s, d, w), trace=True)
        att += sum(t["s"] < 1 for t in res["trace"]); tot += len(res["trace"])
    shares.append((f"{b} {d}D", round(att / tot, 3)))
out["ATT"] = shares
json.dump(out, open(f"{R}/tables.json", "w"), indent=1, ensure_ascii=False)
print(json.dumps(out["T6"], ensure_ascii=False)[:1500]); print(out["ATT"]); print(json.dumps(out["T4"], ensure_ascii=False)[:1200])
