"""Builds the tables (markdown) and statistics from the CSV logs. Usage: python analyze.py results"""
import sys, numpy as np, pandas as pd
from scipy.stats import wilcoxon, rankdata

R = sys.argv[1] if len(sys.argv) > 1 else "results"
METHODS = ["GD+M", "FLO", "HFM"]
CONF = [("Rosenbrock", 2), ("Sphere", 2), ("Himmelblau", 2), ("Ackley", 2), ("Rastrigin", 2), ("Beale", 2), ("Rosenbrock", 10)]
out = []
P = lambda s="": out.append(s)


def fmt(x):
    if x is None or (isinstance(x, float) and np.isnan(x)): return "–"
    if x == 0: return "0"
    return f"{x:.3g}" if 1e-3 <= abs(x) < 1e4 else f"{x:.2e}"


def summ(df):
    ok = df[~df.failed]
    q = ok.f_final.quantile([.25, .5, .75]) if len(ok) else pd.Series([np.nan] * 3, index=[.25, .5, .75])
    return dict(n=len(df), fail=int(df.failed.sum()), mean=ok.f_final.mean(), sd=ok.f_final.std(),
                med=q[.5], q1=q[.25], q3=q[.75])


def rank_biserial(a, b):
    d = np.asarray(a) - np.asarray(b); d = d[d != 0]
    if len(d) == 0: return 0.0
    r = rankdata(np.abs(d)); return (r[d > 0].sum() - r[d < 0].sum()) / r.sum()


def paired_test(df, b, d, m1, m2, col="f_final"):
    x = df[(df.benchmark == b) & (df.dim == d) & (df.method == m1)].set_index("seed")
    y = df[(df.benchmark == b) & (df.dim == d) & (df.method == m2)].set_index("seed")
    j = x.join(y, lsuffix="_1", rsuffix="_2")
    j = j[~j.failed_1 & ~j.failed_2]
    a, c = j[col + "_1"].astype(float).values, j[col + "_2"].astype(float).values
    keep = np.isfinite(a) & np.isfinite(c); a, c = a[keep], c[keep]
    if len(a) == 0 or np.allclose(a, c, rtol=1e-9, atol=1e-12):
        return len(a), np.nan, 0.0
    # treat differences below numerical resolution as ties
    a2 = np.where(np.isclose(a, c, rtol=1e-9, atol=1e-12), c, a)
    p = wilcoxon(a2, c, zero_method="wilcox").pvalue if np.any(a2 != c) else np.nan
    return len(a), p, rank_biserial(a2, c)


def holm(ps):
    ps = np.array(ps, float); idx = [i for i in range(len(ps)) if np.isfinite(ps[i])]
    adj = np.full(len(ps), np.nan); order = sorted(idx, key=lambda i: ps[i]); m = len(order); run = 0
    for k, i in enumerate(order):
        run = max(run, min(1, (m - k) * ps[i])); adj[i] = run
    return adj

# ---------------- Table IV ----------------
e1 = pd.read_csv(f"{R}/E1_main.csv")
P("## Table IV — 500 iterations, 30 starts: median [IQR] of final f over successful runs; failures/30; mean")
P("| Benchmark | " + " | ".join(METHODS) + " |"); P("|---|---|---|---|")
for b, d in CONF:
    cells = []
    for m in METHODS:
        s = summ(e1[(e1.benchmark == b) & (e1.dim == d) & (e1.method == m)])
        cells.append(f"{fmt(s['med'])} [{fmt(s['q1'])}, {fmt(s['q3'])}] f={s['fail']} mean={fmt(s['mean'])}")
    P(f"| {b} {d}D | " + " | ".join(cells) + " |")

# ---------------- Wilcoxon ----------------
P(); P("## Wilcoxon (paired, successful runs of both), Holm over 14 tests; r = matched-pairs rank-biserial (positive => first method has larger f, i.e. worse)")
tests = []
for b, d in CONF:
    for m2 in ["FLO", "GD+M"]:
        n, p, r = paired_test(e1, b, d, "HFM", m2); tests.append([f"{b} {d}D", f"HFM vs {m2}", n, p, r])
adj = holm([t[3] for t in tests])
P("| Benchmark | Comparison | n | p | p_Holm | r |"); P("|---|---|---|---|---|---|")
for t, a in zip(tests, adj): P(f"| {t[0]} | {t[1]} | {t[2]} | {fmt(t[3])} | {fmt(a)} | {t[4]:.2f} |")

# ---------------- Tolerance ----------------
e2 = pd.read_csv(f"{R}/E2_tolerance.csv")
P(); P("## Convergence to f - f* <= 1e-6 (max 5000 iterations): success/30; median iterations; median counted calls (gradient + objective)")
P("| Benchmark | " + " | ".join(METHODS) + " |"); P("|---|---|---|---|")
for b, d in CONF:
    cells = []
    for m in METHODS:
        x = e2[(e2.benchmark == b) & (e2.dim == d) & (e2.method == m)]
        h = x[x.hit_iter.notna()]
        cells.append(f"{len(h)}/30; it={fmt(h.hit_iter.median()) if len(h) else '–'}; calls={fmt(h.hit_cost.median()) if len(h) else '–'}")
    P(f"| {b} {d}D | " + " | ".join(cells) + " |")
P(); P("Paired tests on iterations-to-tolerance (seeds where both succeeded):")
for b, d in CONF:
    for m2 in ["FLO", "GD+M"]:
        n, p, r = paired_test(e2, b, d, "HFM", m2, col="hit_iter")
        if n: P(f"- {b} {d}D HFM vs {m2}: n={n}, p={fmt(p)}, r={r:.2f}")
    for m2 in ["FLO", "GD+M"]:
        n, p, r = paired_test(e2, b, d, "HFM", m2, col="hit_cost")
        if n: P(f"- {b} {d}D HFM vs {m2} (calls): n={n}, p={fmt(p)}, r={r:.2f}")

# ---------------- Himmelblau n=100 ----------------
e4 = pd.read_csv(f"{R}/E4_himmelblau_n100.csv")
P(); P("## Himmelblau, n = 100 starts (5000 max iter)")
for m in METHODS:
    x = e4[e4.method == m]; h = x[x.hit_iter.notna()]
    P(f"- {m}: success {len(h)}/100, median it {fmt(h.hit_iter.median())}, median calls {fmt(h.hit_cost.median())}, median final f {fmt(x.f_final.median())}, fails {int(x.failed.sum())}")
for m2 in ["FLO", "GD+M"]:
    for col in ["hit_iter", "hit_cost", "f_final"]:
        n, p, r = paired_test(e4, "Himmelblau", 2, "HFM", m2, col=col)
        P(f"- HFM vs {m2} on {col}: n={n}, p={fmt(p)}, r={r:.2f}")
# which minimum reached
P(); P("## Scaling (500 iterations): median final f [fails/30], median relative reduction f_T/f_0")
e5 = pd.read_csv(f"{R}/E5_scaling.csv")
for b in ["Rosenbrock", "Rastrigin"]:
    P(f"### {b}"); P("| d | " + " | ".join(METHODS) + " |"); P("|---|---|---|---|")
    for d in sorted(e5.dim.unique()):
        cells = []
        for m in METHODS:
            x = e5[(e5.benchmark == b) & (e5.dim == d) & (e5.method == m)]; ok = x[~x.failed]
            rel = (ok.f_final / ok.f0).median() if len(ok) else np.nan
            cells.append(f"{fmt(ok.f_final.median()) if len(ok) else '–'} [{int(x.failed.sum())}] rel={fmt(rel)}")
        P(f"| {d} | " + " | ".join(cells) + " |")
    P("Paired HFM vs FLO by d: " + "; ".join(
        f"d={d}: p={fmt(paired_test(e5, b, d, 'HFM', 'FLO')[1])}, r={paired_test(e5, b, d, 'HFM', 'FLO')[2]:.2f}"
        for d in sorted(e5.dim.unique())))

# ---------------- Noise ----------------
e6 = pd.read_csv(f"{R}/E6_noise.csv")
P(); P("## Gradient noise: median final f [fails/30]")
for (b, d) in [("Rosenbrock", 2), ("Sphere", 2), ("Ackley", 2), ("Rosenbrock", 10)]:
    P(f"### {b} {d}D"); P("| sigma | " + " | ".join(METHODS) + " |"); P("|---|---|---|---|")
    for sig in sorted(e6.sigma.unique()):
        cells = []
        for m in METHODS:
            x = e6[(e6.benchmark == b) & (e6.dim == d) & (e6.method == m) & (e6.sigma == sig)]; ok = x[~x.failed]
            cells.append(f"{fmt(ok.f_final.median()) if len(ok) else '–'} [{int(x.failed.sum())}]")
        P(f"| {sig} | " + " | ".join(cells) + " |")

# ---------------- Tuned ----------------
e7 = pd.read_csv(f"{R}/E7_tuned_test.csv")
P(); P("## Equal-budget tuned comparison (20 configs each, 10 tuning seeds, evaluated on 30 test seeds): median [fails]; selected config")
P("| Benchmark | " + " | ".join(METHODS) + " |"); P("|---|---|---|---|")
for b, d in CONF:
    cells = []
    for m in METHODS:
        x = e7[(e7.benchmark == b) & (e7.dim == d) & (e7.method == m)]; s = summ(x)
        cells.append(f"{fmt(s['med'])} [{s['fail']}] {x.cfg.iloc[0]}")
    P(f"| {b} {d}D | " + " | ".join(cells) + " |")
tests = []
for b, d in CONF:
    for m2 in ["FLO", "GD+M"]:
        n, p, r = paired_test(e7, b, d, "HFM", m2); tests.append((f"{b} {d}D", m2, n, p, r))
adj = holm([t[3] for t in tests])
for t, a in zip(tests, adj): P(f"- tuned {t[0]} HFM vs {t[1]}: n={t[2]}, p={fmt(t[3])}, p_Holm={fmt(a)}, r={t[4]:.2f}")

# ---------------- Thresholds ----------------
e8 = pd.read_csv(f"{R}/E8_thresholds.csv")
P(); P("## HFM threshold scale (median final f [fails])")
vs = ["scale=0.5", "scale=0.75", "scale=1.0", "scale=1.25", "scale=1.5", "normalized"]
P("| Benchmark | " + " | ".join(vs) + " |"); P("|---" * (len(vs) + 1) + "|")
for b, d in CONF:
    cells = []
    for v in vs:
        x = e8[(e8.benchmark == b) & (e8.dim == d) & (e8.variant == v)]; s = summ(x)
        cells.append(f"{fmt(s['med'])} [{s['fail']}]")
    P(f"| {b} {d}D | " + " | ".join(cells) + " |")

# ---------------- beta_min ----------------
e9 = pd.read_csv(f"{R}/E9_betamin.csv")
P(); P("## HFM beta_min (median final f [fails])")
P("| Benchmark | 0 | 0.1 | 0.2 | 0.3 | 0.4 | 0.5 | 0.7 |"); P("|---|---|---|---|---|---|---|---|")
for b, d in CONF:
    cells = []
    for bm in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.7]:
        x = e9[(e9.benchmark == b) & (e9.dim == d) & (e9.beta_min == bm)]; s = summ(x)
        cells.append(f"{fmt(s['med'])} [{s['fail']}]")
    P(f"| {b} {d}D | " + " | ".join(cells) + " |")

open(f"{R}/summary.md", "w").write("\n".join(out)); print("\n".join(out))
